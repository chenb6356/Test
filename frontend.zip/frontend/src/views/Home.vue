<template>
  <div class="home">
    <h1>ATA - Advanced Test Automation</h1>
    <p>高度集成、可扩展、易用的自动化测试平台</p>
  </div>
</template>

<script setup>
// Home page component
</script>

<style scoped>
.home {
  text-align: center;
  padding: 2rem;
}

h1 {
  color: #409eff;
  margin-bottom: 1rem;
}

p {
  color: #606266;
  font-size: 1.1rem;
}
</style>